#include<stdio.h>
#include<string.h>



void Input(int n, char str[][100]);
void Sub(char sub[]);
int Cari(int n, char str[][100], char sub[]);
void Cari1(int n, char str[][100], char sub[]);