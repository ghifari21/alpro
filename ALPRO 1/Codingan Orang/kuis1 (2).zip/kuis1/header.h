/*
    Saya Sekar Madu Kusumawardani [2007703] mengerjakan 
    soal Kuis 1
    dalam mata kuliah Algoritma dan Pemrograman 1
    untuk keberkahanNya maka saya tidak melakukan kecurangan
    seperti yang telah dispesifikasikan. Aamiin
*/

/*=== LIBRARY ===*/
#include <stdio.h> //----------------------------> library berisi fungsi input output
#include <string.h> //---------------------------> library berisi fungsi pengolah string

/*=== DEKLARASI FUNGSI DAN PROSEDUR ===*/
void Masukan(char str[][100], int n); //---------> prosedur untuk memasukkan string
int Cek(char str[][100], char sub[], int n); //--> fungsi untuk mengecek jumlah subkata