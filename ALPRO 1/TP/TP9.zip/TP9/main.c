/*
   ============================================================
   | Saya Ghifari Octaverin 2000952 mengerjakan TP9           |
   | dalam mata kuliah Algoritma dan Pemrograman              |
   | untuk keberkahanNya maka saya tidak melakukan kecurangan |
   | seperti yang telah dispesifikasikan. Aamiin              |
   ============================================================
*/

#include "header.h"

int main(){
    input(); //memanggil prosedur input
    splittingprocess(); //memanggil prosedur splittingprocess
    changingprocess(); //memanggil prosedur changingprocess
    sortingprocess(); //memanggil prosedur sortingprocess
    output(); //memanggil prosedur output

    return 0;
}